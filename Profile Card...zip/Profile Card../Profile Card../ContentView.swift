//
//  ContentView.swift
//  Profile Card..
//
//  Created by mohammed alsaad on 15/5/2023.
//

import SwiftUI

struct ContentView: View {
    @State var name = ""
    var body: some View {
        
        
        VStack {
            Image("image")
                .resizable().aspectRatio(contentMode: .fit)
                .imageScale(.large)
                .foregroundColor(.white)
                .scaledToFit()
                .frame(width: 200, height: 200)
                .padding()
                
            Text(" Mohammed Alsaad  ")
                .font(Font.custom("SignPainter", size: 40))
                .foregroundColor(.black)
                .padding()
    
            
            HStack{
                Image(systemName: "mail")
                Text("Mohaalsaad.j@gmail.com")
                    .foregroundColor(.black)
                    .font(.system(size: 25, design: .serif))
                    .padding()
            }
            HStack{
                Image(systemName: "calendar")
                Text("1999/Nov/20")
                .font(Font.custom("SignPainter", size: 40))
                .foregroundColor(.black)
                .padding()
                
            }
            TextField("Enter your name ", text: $name)
            Text("\(name)")
                .padding()
                
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.gray)
    }
        
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
