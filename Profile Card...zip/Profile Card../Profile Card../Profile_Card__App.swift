//
//  Profile_Card__App.swift
//  Profile Card..
//
//  Created by mohammed alsaad on 19/12/2022.
//

import SwiftUI

@main
struct Profile_Card__App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
